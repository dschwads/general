#include <stdio.h>

int main()
{
    char s[] = "_pammodutil_getpwnam_\x00test_password";
    sleep(60);
    return 0;
}
