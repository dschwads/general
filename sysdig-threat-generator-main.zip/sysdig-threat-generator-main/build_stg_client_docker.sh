#!/bin/bash
docker build -f ./scripts/Dockerfile . -t sysdig-threat-generator
